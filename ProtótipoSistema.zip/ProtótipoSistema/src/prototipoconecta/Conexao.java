/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototipoconecta;

import java.sql.Connection; //conexão
import java.sql.DriverManager; //gerenciamento de driver de conexão
import java.sql.SQLException; //exceções SQL...


/**
 *
 * @author 20171TINF0056 Artur da silva kalangomon
 */
public class Conexao {
    //tudo ai deve ser privado... senão...
    private Connection con = null;
    private String hostName = null;
    private String userName = null;
    private String password = null;
    private String url = null;
    private String jdbcDriver = null;
    private String dataBaseName = null;
    private String dataBasePrefix = null;
    private String dabaBasePort = null;
     
    
    public Conexao(){    
        /**
    *Os dados setados abaixo servem para uma conexão em MySQL.
    *Altere de acordo com seu BD.
    *Aconselhamos carregar estes dados de um arquivo. 
    */
 
     //"jdbc: mysql:/localhost:3306/meu_bd"; padrão do plugin e mysql_conector()
    hostName = "localhost";
    userName = "root"; //root
    password = "aluno";    
    jdbcDriver = "org.gjt.mm.mysql.Driver";
    dataBaseName = "meu_bd"; //nome da base de testes ou uso
    dataBasePrefix = "jdbc: mysql:/";
    dabaBasePort = "3306"; //padrão... não precisa alterar...
 
    url = dataBasePrefix + hostName + ":"+dabaBasePort+"/" + dataBaseName + "/"; //inclue o hostname, a porta, e no nome da base de dados a ser usado...
 
    /**
    *Exemplo de um URL completo para MySQL:    
    *a concatenação acima deve ficar algo como:
    *jdbc:'mysql:/localhost:3306/meu_bd'
    */
 
}
 
 
  /**
  *Retorna uma java.sql.Connection.
  *@return con 
  */
    public Connection getConexao() {
    try {
        if (con == null) {
        Class.forName(jdbcDriver); //driver jdbc...
      con = DriverManager.getConnection(url, userName, password); //da mesma forma que no php, variavel que recebe a conexão...
    } else if (con.isClosed()) { 
      con = null;
      return getConexao();
    }
    } catch (ClassNotFoundException e) {
        //implementar um login apropriado...
    } catch (SQLException e) {
       // implmentar um sistema de login apropriado...
  }
  return con;
}

    public void closeConexao() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
            //TODO: use um sistema de log apropriado.
            //e.printStackTrace();// desabilitado...
        }
    }
    }


}

//https://www.devmedia.com.br/java-crie-uma-conexao-com-banco-de-dados/5698 << fonte ai... dêem os creditos <.-.< v: 

//função original

/*public Connection getConnection() {
  try {
    if (con == null) {
      Class.forName(jdbcDriver);
      con = DriverManager.getConnection(url, userName, password);
    } else if (con.isClosed()) {
      con = null;
      return getConnection();
    }
  } catch (ClassNotFoundException e) {
 
    //TODO: use um sistema de log apropriado.
 
    e.printStackTrace();
  } catch (SQLException e) {
 
    //TODO: use um sistema de log apropriado.
 
    e.printStackTrace();
  }
  return con;
*/