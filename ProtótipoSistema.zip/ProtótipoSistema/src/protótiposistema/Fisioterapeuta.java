/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protótiposistema;

/**
 *
 * @author 20171TINF0056
 */
public class Fisioterapeuta extends Pessoa{
    private int CRM;

    public Fisioterapeuta(){
        super();
    }
    
    public Fisioterapeuta(int CRM){
        this.CRM = CRM;
    }
    
    public int getCRM(){
        return CRM;
    }
    
    public void setCRM(int CRM){
        this.CRM= CRM;
    }
}
