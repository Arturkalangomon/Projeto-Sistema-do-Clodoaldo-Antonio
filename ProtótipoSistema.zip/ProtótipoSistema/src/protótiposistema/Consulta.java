/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protótiposistema;

/**
 *
 * @author 20171TINF0056
 */
public class Consulta {
    private String descricao;
    private String tratamento;
    
    public Consulta(){
        super();
    }
    
    public Consulta(String descricao, String tratamento){
        this.descricao = descricao;
        this.tratamento = tratamento;
    }
    
    public void setConsulta(String descricao, String tratamento){
        this.descricao = descricao;
        this.tratamento = tratamento;
    }
    
    public String getDescricao(){
        return descricao;
    }
    
    public String getTratamento(){
        return tratamento;
    }
}
