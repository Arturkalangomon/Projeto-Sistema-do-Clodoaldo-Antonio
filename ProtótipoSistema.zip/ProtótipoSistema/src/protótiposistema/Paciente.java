/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protótiposistema;

/**
 *
 * @author 20171TINF0056
 */
public class Paciente extends Pessoa{
    private int cartaoSUS;

    public Paciente(){
        super();
    }

    public Paciente(int cartaoSUS){
        this.cartaoSUS = cartaoSUS;
    }
    
    public int getcartaoSUS(){
        return cartaoSUS;
    }
    
    public void setCartaoSUS(int cartaoSUS){
        this.cartaoSUS = cartaoSUS;
    }


}
