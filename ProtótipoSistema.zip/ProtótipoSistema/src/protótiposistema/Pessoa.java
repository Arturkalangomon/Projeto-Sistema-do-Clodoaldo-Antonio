/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protótiposistema;

/**
 *
 * @author 20171TINF0056
 */
public class Pessoa { //herança.Pessoa
    //atributos - caracteristicas
    private String nome;
    private String endereco;
    private String telefone;
    private int idade;
    
    //construtoes - inicializa
    public Pessoa (String nome, String endereco, String telefone, int idade){
        super();
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.idade = idade;
    }
    
    
    public Pessoa(){
        super();
    }
    //metodo get, acessar um atributo (nome)
    public String getNome(){
        return nome;
    }
    
    public String getTelefone(){
        return telefone;
    }
    
    public String getEndereco(){
        return endereco;
    }
    public int getIdade(){
        return idade;
    }
    
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }
    //metodo set, acessa e modifica um atributo (nome)
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public void setIdade(int idade){
        this.idade = idade;
    }
/*
    void setEndereco(String rua_A) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/
}

